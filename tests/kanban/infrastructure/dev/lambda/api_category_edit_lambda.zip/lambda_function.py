import json
import boto3


def lambda_handler(event, context):
    print('edit category')
    # TODO: This one is complicated and potentially costly... for this to work you would need bulk edit every idea that has the category...  Maybe initially just let you edit description, etc, but not the name?
    
    return respond(500, 'Not Implemented.')


def respond(code, body):
    return {
        'statusCode': code,
        'body': json.dumps(body)
    }