import json
import boto3


dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('ideas_db')

def lambda_handler(event, context):
    print('api_edit_category')
    event_body = json.loads(event['body'])

    try:
        user_id = event['pathParameters']['userid']
        idea_id = event_body['idea_id']
        category = event_body['category']
    except:
        return respond(400, 'Must provide user_id, idea_id, and category.')

    # get item
    try:
        item = table.get_item(
            Key={
                'user_id': user_id,
                'idea_id': idea_id
            }
        )['Item']
    except:
        return respond(404, 'idea not found.')

    # update item
    for attr, val in event_body.items():
        item[attr] = val

    # push changes to db
    table.put_item(
        Item=item
    )

    return respond(200, {'idea': item})


def respond(code, body):
    return {
        'statusCode': code,
        'body': json.dumps(body)
    }