import json
import boto3
import os


client = boto3.client('cognito-idp')

def lambda_handler(event, context):
    # TODO make this pull from event, not be hardcoded
    response = client.sign_up(
        ClientId=os.environ['COGNITO_APP_CLIENT_ID'],
        Username='hoops',
        Password='Test123$',
        UserAttributes=[
            {
                'Name': 'email',
                'Value': 'rwhooperIV@gmail.com'
            },
        ],
        #ValidationData=[
        #    {
        #        'Name': 'string',
        #        'Value': 'string'
        #    },
        #]
    )
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
