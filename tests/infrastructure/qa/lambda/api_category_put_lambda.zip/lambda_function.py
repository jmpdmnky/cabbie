import json
import boto3


dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('ideas_db')

def lambda_handler(event, context):
    print('api_put_category')
    event_body = json.loads(event['body'])

    try:
        new_item = {
            'user_id': event['pathParameters']['userid'],
            'idea_id': '#CATEGORY#{}'.format(event_body['category']),
            'category': event_body['category'],
            'description': ''
        }
    except:
        return respond(400, 'Must provide userid, name, and category.')

    if 'description' in event_body.keys():
        new_item['description'] = event_body['description']

    try:
        response = table.put_item(
            Item={
                **new_item
            },
            ConditionExpression='attribute_not_exists(idea_id) AND attribute_not_exists(user_id)'
        )
    except:
        return respond(502, 'Category already exists.')
    
    return respond(200, 'Category created.')


def respond(code, body):
    return {
        'statusCode': code,
        'body': json.dumps(body)
    }